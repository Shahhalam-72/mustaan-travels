import FirebaseBookingPage from "./FirebaseBookingPage"

export const metadata = {
  title: "Book Your Northern Pakistan Adventure | Musta'an Travels",
  description:
    "Book your dream trip to Malam Jabba, Kalam Valley, or Kumrat Valley. Easy online booking with instant confirmation. All-inclusive packages available.",
}

export default function BookingPage() {
  return <FirebaseBookingPage />
}
