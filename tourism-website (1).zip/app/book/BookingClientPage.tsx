"use client"
import { useState } from "react"
import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, Users, Phone, Mail, MapPin, CreditCard, CheckCircle } from "lucide-react"
import Link from "next/link"

export default function BookingClientPage() {
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [selectedPackage, setSelectedPackage] = useState("")
  const [numberOfPersons, setNumberOfPersons] = useState(1)

  const packages = [
    { id: "malam-jabba", name: "Malam Jabba Tour", price: 14500, duration: "3 Days / 2 Nights" },
    { id: "kalam-valley", name: "Kalam Valley Nature Retreat", price: 30000, duration: "4 Days / 3 Nights" },
    { id: "kumrat-valley", name: "Kumrat Valley Wilderness", price: 35000, duration: "5 Days / 4 Nights" },
  ]

  const selectedPackageDetails = packages.find((pkg) => pkg.id === selectedPackage)
  const totalPrice = selectedPackageDetails ? selectedPackageDetails.price * numberOfPersons : 0

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitted(true)
  }

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          {/* Header */}
          <nav className="bg-white shadow-md px-6 py-4 flex justify-between items-center sticky top-0 z-50">
            <div className="text-2xl font-extrabold text-blue-700">Musta'an Travels</div>
            <div className="space-x-4 text-gray-700 font-medium">
              <Link href="/" className="hover:text-blue-600">
                Home
              </Link>
              <Link href="/malam-jabba" className="hover:text-blue-600">
                Malam Jabba
              </Link>
              <Link href="/book" className="hover:text-blue-600">
                Book
              </Link>
            </div>
          </nav>

          <Card className="max-w-2xl mx-auto text-center">
            <CardContent className="pt-8 pb-8">
              <div className="bg-emerald-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-10 w-10 text-emerald-600" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Booking Submitted Successfully!</h1>
              <p className="text-lg text-gray-600 mb-6">
                Thank you for choosing Northern Adventures. We've received your booking request and will contact you
                within 24 hours to confirm your trip details.
              </p>
              <div className="bg-gray-50 rounded-lg p-4 mb-6">
                <p className="text-sm text-gray-600">
                  <strong>Reference ID:</strong> NA-{Math.random().toString(36).substr(2, 9).toUpperCase()}
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild className="bg-emerald-600 hover:bg-emerald-700">
                  <Link href="/">Return to Homepage</Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="/contact">Contact Us</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
          {/* Footer */}
          <footer className="bg-gray-100 text-center py-6 mt-10 text-sm text-gray-600">
            © 2025 Musta'an Travels. All rights reserved. | WhatsApp: +92-340-0986073
          </footer>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <nav className="bg-white shadow-md px-6 py-4 flex justify-between items-center sticky top-0 z-50">
          <div className="text-2xl font-extrabold text-blue-700">Musta'an Travels</div>
          <div className="space-x-4 text-gray-700 font-medium">
            <Link href="/" className="hover:text-blue-600">
              Home
            </Link>
            <Link href="/malam-jabba" className="hover:text-blue-600">
              Malam Jabba
            </Link>
            <Link href="/book" className="hover:text-blue-600">
              Book
            </Link>
          </div>
        </nav>
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center space-x-2 text-emerald-600 hover:text-emerald-700 mb-4">
            <MapPin className="h-5 w-5" />
            <span className="font-semibold">Northern Adventures</span>
          </Link>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Book Your Adventure</h1>
          <p className="text-lg text-gray-600">Fill out the form below to reserve your spot</p>
        </div>

        <div className="max-w-4xl mx-auto grid lg:grid-cols-3 gap-8">
          {/* Booking Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="h-5 w-5 text-emerald-600" />
                  <span>Booking Details</span>
                </CardTitle>
                <CardDescription>Please provide your information and trip preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Package Selection */}
                  <div className="space-y-2">
                    <Label htmlFor="package">Select Package *</Label>
                    <Select value={selectedPackage} onValueChange={setSelectedPackage} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose your destination" />
                      </SelectTrigger>
                      <SelectContent>
                        {packages.map((pkg) => (
                          <SelectItem key={pkg.id} value={pkg.id}>
                            <div className="flex justify-between items-center w-full">
                              <span>{pkg.name}</span>
                              <span className="ml-4 text-emerald-600 font-semibold">
                                PKR {pkg.price.toLocaleString()}
                              </span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Personal Information */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Full Name *</Label>
                      <Input id="fullName" type="text" placeholder="Enter your full name" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input id="phone" type="tel" placeholder="+92 300 1234567" required />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input id="email" type="email" placeholder="your.email@example.com" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="persons">Number of Persons *</Label>
                      <Select
                        value={numberOfPersons.toString()}
                        onValueChange={(value) => setNumberOfPersons(Number.parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                            <SelectItem key={num} value={num.toString()}>
                              {num} {num === 1 ? "Person" : "Persons"}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Travel Dates */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="departure">Preferred Departure Date</Label>
                      <Input id="departure" type="date" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="pickup">Pickup Location</Label>
                      <Select defaultValue="islamabad">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="islamabad">Islamabad</SelectItem>
                          <SelectItem value="rawalpindi">Rawalpindi</SelectItem>
                          <SelectItem value="lahore">Lahore</SelectItem>
                          <SelectItem value="karachi">Karachi</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Special Requests */}
                  <div className="space-y-2">
                    <Label htmlFor="requests">Special Requests or Requirements</Label>
                    <Textarea
                      id="requests"
                      placeholder="Any dietary restrictions, accessibility needs, or special occasions we should know about?"
                      rows={4}
                    />
                  </div>

                  {/* Terms and Conditions */}
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <input type="checkbox" id="terms" className="mt-1" required />
                      <label htmlFor="terms" className="text-sm text-gray-600">
                        I agree to the{" "}
                        <Link href="/terms" className="text-emerald-600 hover:underline">
                          Terms and Conditions
                        </Link>{" "}
                        and{" "}
                        <Link href="/privacy" className="text-emerald-600 hover:underline">
                          Privacy Policy
                        </Link>
                      </label>
                    </div>
                  </div>

                  <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 text-lg py-6">
                    Submit Booking Request
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Booking Summary */}
          <div className="lg:col-span-1">
            <Card className="sticky top-6">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CreditCard className="h-5 w-5 text-emerald-600" />
                  <span>Booking Summary</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedPackageDetails ? (
                  <>
                    <div className="bg-emerald-50 rounded-lg p-4">
                      <h3 className="font-semibold text-emerald-900">{selectedPackageDetails.name}</h3>
                      <p className="text-sm text-emerald-700">{selectedPackageDetails.duration}</p>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Package Price:</span>
                        <span>PKR {selectedPackageDetails.price.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Number of Persons:</span>
                        <span>{numberOfPersons}</span>
                      </div>
                      <div className="border-t pt-3">
                        <div className="flex justify-between font-semibold text-lg">
                          <span>Total Amount:</span>
                          <span className="text-emerald-600">PKR {totalPrice.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-blue-50 rounded-lg p-4">
                      <h4 className="font-semibold text-blue-900 mb-2">What's Included:</h4>
                      <ul className="text-sm text-blue-700 space-y-1">
                        <li>• Transportation</li>
                        <li>• Accommodation</li>
                        <li>• Meals (as specified)</li>
                        <li>• Professional Guide</li>
                        <li>• Photography</li>
                      </ul>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Select a package to see pricing details</p>
                  </div>
                )}

                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Need Help?</h4>
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex items-center space-x-2">
                      <Phone className="h-4 w-4" />
                      <span>+92-340-0986073</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4" />
                      <span>info@northernadventures.pk</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        {/* Footer */}
        <footer className="bg-gray-100 text-center py-6 mt-10 text-sm text-gray-600">
          © 2025 Musta'an Travels. All rights reserved. | WhatsApp: +92-340-0986073
        </footer>
      </div>
    </div>
  )
}
