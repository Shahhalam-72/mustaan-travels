"use client"
import { useState } from "react"
import { db } from "../../lib/firebase"
import { collection, addDoc } from "firebase/firestore"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, Users, Phone, Mail, CreditCard, CheckCircle, AlertCircle } from "lucide-react"
import Link from "next/link"

export default function FirebaseBookingPage() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    persons: "",
    package: "",
    departureDate: "",
    pickupLocation: "islamabad",
    notes: "",
    submittedAt: "",
  })

  const [success, setSuccess] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const packages = [
    { id: "malam-jabba", name: "Malam Jabba Tour", price: 14500, duration: "3 Days / 2 Nights" },
    { id: "kalam-valley", name: "Kalam Valley Nature Retreat", price: 30000, duration: "4 Days / 3 Nights" },
    { id: "kumrat-valley", name: "Kumrat Valley Wilderness", price: 35000, duration: "5 Days / 4 Nights" },
  ]

  const selectedPackageDetails = packages.find((pkg) => pkg.id === formData.package)
  const totalPrice = selectedPackageDetails
    ? selectedPackageDetails.price * (Number.parseInt(formData.persons) || 1)
    : 0

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSelectChange = (name, value) => {
    setFormData({ ...formData, [name]: value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const bookingData = {
        ...formData,
        submittedAt: new Date().toISOString(),
        totalPrice: totalPrice,
        packageDetails: selectedPackageDetails,
        status: "pending",
      }

      await addDoc(collection(db, "bookings"), bookingData)
      setSuccess(true)
      setFormData({
        name: "",
        phone: "",
        email: "",
        persons: "",
        package: "",
        departureDate: "",
        pickupLocation: "islamabad",
        notes: "",
        submittedAt: "",
      })
    } catch (error) {
      setError("Error submitting form: " + error.message)
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <nav className="bg-white shadow-md px-6 py-4 flex justify-between items-center sticky top-0 z-50">
          <div className="text-2xl font-extrabold text-blue-700">Musta'an Travels</div>
          <div className="space-x-4 text-gray-700 font-medium">
            <Link href="/" className="hover:text-blue-600">
              Home
            </Link>
            <Link href="/malam-jabba" className="hover:text-blue-600">
              Malam Jabba
            </Link>
            <Link href="/book" className="hover:text-blue-600">
              Book
            </Link>
          </div>
        </nav>

        <div className="container mx-auto px-4 py-12">
          <Card className="max-w-2xl mx-auto text-center">
            <CardContent className="pt-8 pb-8">
              <div className="bg-emerald-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-10 w-10 text-emerald-600" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Booking Submitted Successfully!</h1>
              <p className="text-lg text-gray-600 mb-6">
                Thank you for choosing Musta'an Travels. We've received your booking request and will contact you within
                24 hours to confirm your trip details.
              </p>
              <div className="bg-gray-50 rounded-lg p-4 mb-6">
                <p className="text-sm text-gray-600">
                  <strong>Reference ID:</strong> MT-{Math.random().toString(36).substr(2, 9).toUpperCase()}
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild className="bg-emerald-600 hover:bg-emerald-700">
                  <Link href="/">Return to Homepage</Link>
                </Button>
                <Button variant="outline" onClick={() => setSuccess(false)}>
                  Book Another Trip
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Footer */}
        <footer className="bg-gray-100 text-center py-6 mt-10 text-sm text-gray-600">
          © 2025 Musta'an Travels. All rights reserved. | WhatsApp: +92-340-0986073
        </footer>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <nav className="bg-white shadow-md px-6 py-4 flex justify-between items-center sticky top-0 z-50">
        <div className="text-2xl font-extrabold text-blue-700">Musta'an Travels</div>
        <div className="space-x-4 text-gray-700 font-medium">
          <Link href="/" className="hover:text-blue-600">
            Home
          </Link>
          <Link href="/malam-jabba" className="hover:text-blue-600">
            Malam Jabba
          </Link>
          <Link href="/book" className="hover:text-blue-600">
            Book
          </Link>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">Book Your Adventure</h1>
          <p className="text-lg text-gray-600">Fill out the form below to reserve your spot</p>
        </div>

        {error && (
          <div className="max-w-4xl mx-auto mb-6">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center space-x-3">
              <AlertCircle className="h-5 w-5 text-red-600" />
              <p className="text-red-800">{error}</p>
            </div>
          </div>
        )}

        <div className="max-w-4xl mx-auto grid lg:grid-cols-3 gap-8">
          {/* Booking Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="h-5 w-5 text-emerald-600" />
                  <span>Booking Details</span>
                </CardTitle>
                <CardDescription>Please provide your information and trip preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Package Selection */}
                  <div className="space-y-2">
                    <Label htmlFor="package">Select Package *</Label>
                    <Select
                      value={formData.package}
                      onValueChange={(value) => handleSelectChange("package", value)}
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Choose your destination" />
                      </SelectTrigger>
                      <SelectContent>
                        {packages.map((pkg) => (
                          <SelectItem key={pkg.id} value={pkg.id}>
                            <div className="flex justify-between items-center w-full">
                              <span>{pkg.name}</span>
                              <span className="ml-4 text-emerald-600 font-semibold">
                                PKR {pkg.price.toLocaleString()}
                              </span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Personal Information */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        name="name"
                        type="text"
                        placeholder="Enter your full name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        placeholder="+92 300 1234567"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="your.email@example.com"
                        value={formData.email}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="persons">Number of Persons *</Label>
                      <Input
                        id="persons"
                        name="persons"
                        type="number"
                        placeholder="Number of travelers"
                        value={formData.persons}
                        onChange={handleChange}
                        min="1"
                        max="10"
                        required
                      />
                    </div>
                  </div>

                  {/* Travel Dates */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="departureDate">Preferred Departure Date</Label>
                      <Input
                        id="departureDate"
                        name="departureDate"
                        type="date"
                        value={formData.departureDate}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="pickupLocation">Pickup Location</Label>
                      <Select
                        value={formData.pickupLocation}
                        onValueChange={(value) => handleSelectChange("pickupLocation", value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="islamabad">Islamabad</SelectItem>
                          <SelectItem value="rawalpindi">Rawalpindi</SelectItem>
                          <SelectItem value="lahore">Lahore</SelectItem>
                          <SelectItem value="karachi">Karachi</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Special Requests */}
                  <div className="space-y-2">
                    <Label htmlFor="notes">Special Requests or Requirements</Label>
                    <Textarea
                      id="notes"
                      name="notes"
                      placeholder="Any dietary restrictions, accessibility needs, or special occasions we should know about?"
                      rows={4}
                      value={formData.notes}
                      onChange={handleChange}
                    />
                  </div>

                  {/* Terms and Conditions */}
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <input type="checkbox" id="terms" className="mt-1" required />
                      <label htmlFor="terms" className="text-sm text-gray-600">
                        I agree to the{" "}
                        <Link href="/terms" className="text-emerald-600 hover:underline">
                          Terms and Conditions
                        </Link>{" "}
                        and{" "}
                        <Link href="/privacy" className="text-emerald-600 hover:underline">
                          Privacy Policy
                        </Link>
                      </label>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-lg py-6"
                    disabled={loading}
                  >
                    {loading ? "Submitting..." : "Submit Booking Request"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Booking Summary */}
          <div className="lg:col-span-1">
            <Card className="sticky top-6">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CreditCard className="h-5 w-5 text-emerald-600" />
                  <span>Booking Summary</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedPackageDetails ? (
                  <>
                    <div className="bg-emerald-50 rounded-lg p-4">
                      <h3 className="font-semibold text-emerald-900">{selectedPackageDetails.name}</h3>
                      <p className="text-sm text-emerald-700">{selectedPackageDetails.duration}</p>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Package Price:</span>
                        <span>PKR {selectedPackageDetails.price.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Number of Persons:</span>
                        <span>{formData.persons || 1}</span>
                      </div>
                      <div className="border-t pt-3">
                        <div className="flex justify-between font-semibold text-lg">
                          <span>Total Amount:</span>
                          <span className="text-emerald-600">PKR {totalPrice.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-blue-50 rounded-lg p-4">
                      <h4 className="font-semibold text-blue-900 mb-2">What's Included:</h4>
                      <ul className="text-sm text-blue-700 space-y-1">
                        <li>• Transportation</li>
                        <li>• Accommodation</li>
                        <li>• Meals (as specified)</li>
                        <li>• Professional Guide</li>
                        <li>• Photography</li>
                      </ul>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Select a package to see pricing details</p>
                  </div>
                )}

                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Need Help?</h4>
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex items-center space-x-2">
                      <Phone className="h-4 w-4" />
                      <span>+92-340-0986073</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4" />
                      <span>info@mustaantravels.pk</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-100 text-center py-6 mt-10 text-sm text-gray-600">
        © 2025 Musta'an Travels. All rights reserved. | WhatsApp: +92-340-0986073
      </footer>
    </div>
  )
}
