import Link from "next/link"
import MalamJabbaPackage from "../../components/malam-jabba-package"

export const metadata = {
  title: "Malam Jabba Package Details | Ski Resort Adventure | Musta'an Travels",
  description:
    "Complete details of our Malam Jabba ski resort package. Includes cable car rides, mountain photography, local cuisine, and professional guide. Book now for August 2025.",
}

export default function MalamJabbaPackagePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <nav className="bg-white shadow-md px-6 py-4 flex justify-between items-center sticky top-0 z-50">
        <div className="text-2xl font-extrabold text-blue-700">Musta'an Travels</div>
        <div className="space-x-4 text-gray-700 font-medium">
          <Link href="/" className="hover:text-blue-600">
            Home
          </Link>
          <Link href="/malam-jabba" className="hover:text-blue-600">
            Malam Jabba
          </Link>
          <Link href="/book" className="hover:text-blue-600">
            Book
          </Link>
        </div>
      </nav>

      {/* Page Content */}
      <div className="container mx-auto px-4 lg:px-6 py-12">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Malam Jabba Package Details</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover all the details about our exclusive Malam Jabba ski resort adventure package
          </p>
        </div>

        <MalamJabbaPackage />

        {/* Additional Information */}
        <div className="mt-12 max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="text-xl font-semibold mb-4">Important Information</h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Valid passport required for all travelers</li>
                <li>• Minimum age requirement: 12 years</li>
                <li>• Weather-appropriate clothing recommended</li>
                <li>• Travel insurance is recommended</li>
                <li>• Cancellation policy: 48 hours before departure</li>
              </ul>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h3 className="text-xl font-semibold mb-4">What to Bring</h3>
              <ul className="space-y-2 text-gray-600">
                <li>• Warm clothing and jackets</li>
                <li>• Comfortable hiking shoes</li>
                <li>• Personal medications</li>
                <li>• Camera and extra batteries</li>
                <li>• Sunglasses and sunscreen</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="bg-gray-100 text-center py-6 mt-10 text-sm text-gray-600">
          © 2025 Musta'an Travels. All rights reserved. | WhatsApp: +92-340-0986073
        </footer>
      </div>
    </div>
  )
}
