import Link from "next/link"
import MalamJabbaPackage from "../components/malam-jabba-package"

export const metadata = {
  title: "Malam Jabba Tour Package | 3 Days PKR 14,500 | Musta'an Travels",
  description:
    "Experience Pakistan's premier ski resort with our exclusive Malam Jabba package. 3 days, 2 nights including transport, accommodation, meals & guide from Islamabad.",
}

export default function Page() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <nav className="bg-white shadow-md px-6 py-4 flex justify-between items-center sticky top-0 z-50">
        <div className="text-2xl font-extrabold text-blue-700">Musta'an Travels</div>
        <div className="space-x-4 text-gray-700 font-medium">
          <Link href="/" className="hover:text-blue-600">
            Home
          </Link>
          <Link href="/malam-jabba" className="hover:text-blue-600">
            Malam Jabba
          </Link>
          <Link href="/book" className="hover:text-blue-600">
            Book
          </Link>
        </div>
      </nav>

      {/* Page Content */}
      <div className="container mx-auto px-4 lg:px-6 py-12">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Malam Jabba Package Details</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover all the details about our exclusive Malam Jabba ski resort adventure package
          </p>
        </div>

        <MalamJabbaPackage />
      </div>

      {/* Footer */}
      <footer className="bg-gray-100 text-center py-6 mt-10 text-sm text-gray-600">
        © 2025 Musta'an Travels. All rights reserved. | WhatsApp: +92-340-0986073
      </footer>
    </div>
  )
}
