"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, MapPin, DollarSign, Check, Users, Camera, Utensils, Car, Hotel } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function MalamJabbaPackage() {
  const inclusions = [
    { icon: Car, text: "Luxury Transportation" },
    { icon: Hotel, text: "Hotel Accommodation" },
    { icon: Utensils, text: "Breakfast & Dinner" },
    { icon: Camera, text: "Photography" },
    { icon: Users, text: "Tour Guide" },
  ]

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300">
        <div className="relative h-80">
          <Image
            src="https://upload.wikimedia.org/wikipedia/commons/3/33/Malam_Jabba_Swat.jpg"
            alt="Malam Jabba Ski Resort"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute top-4 left-4">
            <Badge className="bg-red-500 text-white font-semibold">Special Offer</Badge>
          </div>
          <div className="absolute top-4 right-4">
            <Badge className="bg-emerald-600 text-white">Limited Seats</Badge>
          </div>
        </div>

        <CardHeader className="pb-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle className="text-2xl md:text-3xl font-bold text-gray-900">Malam Jabba Tour Package</CardTitle>
              <CardDescription className="text-lg text-gray-600 mt-2">
                Experience Pakistan's premier ski resort destination
              </CardDescription>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-emerald-600">PKR 14,500</div>
              <div className="text-sm text-gray-500">per person</div>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Package Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Package Details</h3>

              <div className="flex items-center space-x-3">
                <Calendar className="h-5 w-5 text-emerald-600" />
                <div>
                  <span className="font-medium">Dates:</span>
                  <span className="ml-2 text-gray-700">16 - 18 August 2025</span>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Clock className="h-5 w-5 text-emerald-600" />
                <div>
                  <span className="font-medium">Duration:</span>
                  <span className="ml-2 text-gray-700">2 Nights, 3 Days</span>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-emerald-600" />
                <div>
                  <span className="font-medium">Departure:</span>
                  <span className="ml-2 text-gray-700">Islamabad</span>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <DollarSign className="h-5 w-5 text-emerald-600" />
                <div>
                  <span className="font-medium">Price:</span>
                  <span className="ml-2 text-gray-700">PKR 14,500 per person</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">What's Included</h3>
              <div className="space-y-3">
                {inclusions.map((item, index) => {
                  const IconComponent = item.icon
                  return (
                    <div key={index} className="flex items-center space-x-3">
                      <div className="bg-emerald-100 p-1.5 rounded-full">
                        <IconComponent className="h-4 w-4 text-emerald-600" />
                      </div>
                      <span className="text-gray-700">{item.text}</span>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>

          {/* Highlights Section */}
          <div className="bg-gray-50 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Trip Highlights</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                "Ski Resort Experience",
                "Cable Car Rides",
                "Mountain Photography",
                "Local Cuisine Tasting",
                "Scenic Valley Views",
                "Professional Guide",
              ].map((highlight, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <Check className="h-4 w-4 text-emerald-600" />
                  <span className="text-gray-700 text-sm">{highlight}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <Button asChild className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-lg py-6">
              <Link href="/book">Book Now - PKR 14,500</Link>
            </Button>
            <Button
              variant="outline"
              className="flex-1 border-emerald-600 text-emerald-600 hover:bg-emerald-50 text-lg py-6 bg-transparent"
            >
              Get More Details
            </Button>
          </div>

          {/* Additional Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <div className="bg-blue-100 p-1 rounded-full mt-0.5">
                <Calendar className="h-4 w-4 text-blue-600" />
              </div>
              <div>
                <h4 className="font-medium text-blue-900">Limited Time Offer</h4>
                <p className="text-sm text-blue-700 mt-1">
                  Book before July 31st, 2025 and save PKR 2,000! Only 15 seats available for this exclusive package.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
