import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Star, Calendar, Users } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import MalamJabbaPackage from "./components/malam-jabba-package"

export const metadata = {
  title: "Musta'an Travels – Northern Pakistan Tour Experts",
  description:
    "Book premium tour packages from Islamabad to Malam Jabba, Kalam & Kumrat with Musta'an Travels. Transport, Stay, Food – All Included.",
}

export default function HomePage() {
  const featuredTrips = [
    {
      id: 1,
      destination: "Malam Jabba",
      title: "Malam Jabba Ski Resort Adventure",
      description:
        "Experience Pakistan's premier ski resort with snow-capped mountains, skiing facilities, and breathtaking alpine scenery.",
      duration: "3 Days / 2 Nights",
      price: "PKR 25,000",
      rating: 4.8,
      image: "/placeholder.svg?height=300&width=400",
      highlights: ["Skiing & Snowboarding", "Cable Car Rides", "Mountain Views", "Local Cuisine"],
    },
    {
      id: 2,
      destination: "Kalam Valley",
      title: "Kalam Valley Nature Retreat",
      description:
        "Discover the pristine beauty of Kalam Valley with its lush green meadows, crystal-clear rivers, and majestic peaks.",
      duration: "4 Days / 3 Nights",
      price: "PKR 30,000",
      rating: 4.9,
      image: "/placeholder.svg?height=300&width=400",
      highlights: ["River Rafting", "Hiking Trails", "Photography", "Camping"],
    },
    {
      id: 3,
      destination: "Kumrat Valley",
      title: "Kumrat Valley Wilderness Experience",
      description:
        "Explore the untouched wilderness of Kumrat Valley with its dense forests, waterfalls, and stunning mountain landscapes.",
      duration: "5 Days / 4 Nights",
      price: "PKR 35,000",
      rating: 4.7,
      image: "/placeholder.svg?height=300&width=400",
      highlights: ["Waterfall Trekking", "Forest Camping", "Wildlife Spotting", "Photography"],
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <nav className="bg-white shadow-md px-6 py-4 flex justify-between items-center sticky top-0 z-50">
        <div className="text-2xl font-extrabold text-blue-700">Musta'an Travels</div>
        <div className="space-x-4 text-gray-700 font-medium">
          <Link href="/" className="hover:text-blue-600">
            Home
          </Link>
          <Link href="/malam-jabba" className="hover:text-blue-600">
            Malam Jabba
          </Link>
          <Link href="/book" className="hover:text-blue-600">
            Book
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/40 z-10" />
        <Image
          src="/placeholder.svg?height=600&width=1200"
          alt="Northern Pakistan Mountains"
          fill
          className="object-cover"
          priority
        />
        <div className="relative z-20 text-center text-white max-w-4xl mx-auto px-4">
          <Badge className="mb-4 bg-emerald-600 hover:bg-emerald-700">Departing from Islamabad</Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Discover Pakistan's
            <span className="block text-emerald-400">Northern Paradise</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-2xl mx-auto">
            Experience the breathtaking beauty of Malam Jabba, Kalam, and Kumrat Valley with our expertly crafted tour
            packages
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild className="bg-emerald-600 hover:bg-emerald-700 text-lg px-8 py-3">
              <Link href="/book">Book Your Adventure</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-gray-900 text-lg px-8 py-3 bg-transparent"
            >
              View Packages
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Trips Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-emerald-100 text-emerald-800 hover:bg-emerald-200">Featured Destinations</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Explore Northern Pakistan's Gems</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              From the ski slopes of Malam Jabba to the pristine valleys of Kalam and Kumrat, discover Pakistan's most
              stunning destinations
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredTrips.map((trip) => (
              <Card key={trip.id} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <div className="relative h-64">
                  <Image src={trip.image || "/placeholder.svg"} alt={trip.destination} fill className="object-cover" />
                  <Badge className="absolute top-4 left-4 bg-emerald-600">{trip.destination}</Badge>
                </div>
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <CardTitle className="text-xl">{trip.title}</CardTitle>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm font-medium">{trip.rating}</span>
                    </div>
                  </div>
                  <CardDescription className="text-gray-600">{trip.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2 text-sm text-gray-500">
                      <Calendar className="h-4 w-4" />
                      <span>{trip.duration}</span>
                    </div>
                    <div className="text-2xl font-bold text-emerald-600">{trip.price}</div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-semibold text-sm text-gray-900">Trip Highlights:</h4>
                    <div className="flex flex-wrap gap-2">
                      {trip.highlights.map((highlight, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {highlight}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button asChild className="w-full bg-emerald-600 hover:bg-emerald-700">
                    <Link href="/book">Book This Trip</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Why Choose Northern Adventures?</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We provide exceptional travel experiences with local expertise and personalized service
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-emerald-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Expert Guides</h3>
              <p className="text-gray-600">Local guides with extensive knowledge of northern Pakistan</p>
            </div>
            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-emerald-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Best Locations</h3>
              <p className="text-gray-600">Carefully selected destinations for maximum experience</p>
            </div>
            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-emerald-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">5-Star Service</h3>
              <p className="text-gray-600">Premium accommodations and exceptional customer service</p>
            </div>
            <div className="text-center">
              <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="h-8 w-8 text-emerald-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Flexible Booking</h3>
              <p className="text-gray-600">Easy booking process with flexible cancellation policies</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Package Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-emerald-100 text-emerald-800 hover:bg-emerald-200">Featured Package</Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Special August Offer</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Don't miss our exclusive Malam Jabba package for August 2025
            </p>
            <div className="mt-4">
              <Button variant="outline" asChild>
                <Link href="/packages/malam-jabba">View Full Details</Link>
              </Button>
            </div>
          </div>
          <MalamJabbaPackage />
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-emerald-600">
        <div className="container mx-auto px-4 lg:px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Ready for Your Northern Adventure?</h2>
          <p className="text-xl text-emerald-100 mb-8 max-w-2xl mx-auto">
            Book your dream trip to Pakistan's northern valleys today and create memories that will last a lifetime
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild className="bg-white text-emerald-600 hover:bg-gray-100 text-lg px-8 py-3">
              <Link href="/book">Book Now - Starting from PKR 25,000</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-emerald-600 text-lg px-8 py-3 bg-transparent"
            >
              Get Free Consultation
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-100 text-center py-6 mt-10 text-sm text-gray-600">
        © 2025 Musta'an Travels. All rights reserved. | WhatsApp: +92-340-0986073
      </footer>
    </div>
  )
}
